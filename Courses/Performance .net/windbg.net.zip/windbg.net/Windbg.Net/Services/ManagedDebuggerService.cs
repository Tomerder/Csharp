﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using ClrMD.Extensions;
using Microsoft.Diagnostics.Runtime;
using Windbg.Net.Infra;
using Windbg.Net.Models;

namespace Windbg.Net.Services
{
    public class ManagedDebuggerService : IDisposable
    {
        public void Dispose()
        {
            _clrMdSession?.Dispose();
        }

        private ClrMDSession _clrMdSession;

        public ClrMDSession LoadDumpFile(string dumpFilePath)
        {
            return _clrMdSession = ClrMDSession.LoadCrashDump(dumpFilePath);
        }

        public ClrMDSession AttachToProcess(int pid)
        {
            return _clrMdSession = ClrMDSession.AttachToProcess(pid);
        }

        public ObservableCollection<Stat> GetStats()
        {
            return (from obj in _clrMdSession.AllObjects
                    group obj by obj.TypeName
                into typesGroup
                    let typeSize = typesGroup.Sum(o => (int)o.Size)
                    let instances = typesGroup.Count()
                    orderby typeSize descending
                    select new Stat { TypeName = typesGroup.Key, Count = instances, TotalSize = typeSize }).ToObservableCollection();
        }

        public ObservableCollection<ClrThread> GetThreads()
        {
            return _clrMdSession.Runtime.Threads.ToObservableCollection();
        }

        public IEnumerable<Deadlock> FindDeadLocks()
        {
            return from blockingObject in _clrMdSession.Heap.EnumerateBlockingObjects()
                   let deadlockList = new HashSet<ClrThread>()
                   let hasDeadLock = IsDeadLocked(blockingObject, deadlockList)
                   where hasDeadLock
                   select
                       new Deadlock
                       {
                           ThreadId = blockingObject.Waiters[0].ManagedThreadId,
                           WaitingForThreadId = blockingObject.Owner.ManagedThreadId,
                           BlockingObject =
                               new ClrObject(blockingObject.Object, _clrMdSession.Heap.GetObjectType(blockingObject.Object))
                                   .ToDetailedString()
                       };
        }

        private static bool IsDeadLocked(BlockingObject blockingObject, HashSet<ClrThread> deadlockedThreads = null)
        {
            deadlockedThreads = deadlockedThreads ?? new HashSet<ClrThread>();

            if (blockingObject.Waiters.Count == 0 || blockingObject.Owner == null)
                return false;

            if (blockingObject.HasSingleOwner && deadlockedThreads.Contains(blockingObject.Owner))
                return true;

            deadlockedThreads.Add(blockingObject.Owner);

            return
                blockingObject.Waiters.Any(
                    thread => thread.BlockingObjects.Any(obj => IsDeadLocked(obj, deadlockedThreads)));
        }
    }
}
