﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windbg.Net.Models
{
    public class Stat
    {
        public string TypeName { get; set; }
        public int Count { get; set; }
        public int TotalSize { get; set; }
    }
}
