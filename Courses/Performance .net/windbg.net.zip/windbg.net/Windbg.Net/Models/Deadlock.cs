﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windbg.Net.Models
{
    public class Deadlock
    {
        public int ThreadId { get; set; }
        public int WaitingForThreadId { get; set; }
        public string BlockingObject { get; set; }

        public override string ToString()
        {
            return
                $"Thread {ThreadId} is waiting for thread {WaitingForThreadId} using lock {BlockingObject}";
        }
    }
}
