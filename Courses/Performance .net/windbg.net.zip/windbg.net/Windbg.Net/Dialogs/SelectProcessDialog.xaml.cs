﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Windbg.Net.Dialogs
{
    /// <summary>
    /// Interaction logic for SelectProcessDialog.xaml
    /// </summary>
    public partial class SelectProcessDialog : Window
    {
        public SelectProcessDialog()
        {
            InitializeComponent();

            this.Loaded += SelectProcessDialog_Loaded;
        }

        void SelectProcessDialog_Loaded(object sender, RoutedEventArgs e)
        {
            FullProcessList = Process.GetProcesses().OrderBy(p => p.ProcessName).ToList();

            // Loading process list
            processesList.ItemsSource = FullProcessList;
        }

        public List<Process> FullProcessList { get; set; }

        public Process SelectedProcess { get; private set; }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            if (processesList.SelectedItem != null)
            {
                SelectedProcess = processesList.SelectedItem as Process;
                this.Hide();
            }
        }

        private void SearchProcessName_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            // Todo: Change this shitty implementation
            processesList.ItemsSource = FullProcessList.Where(p => p.ProcessName.ToLower().Contains(searchProcessName.Text.ToLower())).
                OrderBy(p => p.ProcessName).ToList();
        }
    }
}
