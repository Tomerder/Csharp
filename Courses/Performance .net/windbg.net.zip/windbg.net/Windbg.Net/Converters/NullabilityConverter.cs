﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Windbg.Net.Converters
{
    public class NullabilityConverter<T> : IValueConverter
    {
        public T NullValue { get; set; }
        public T NotNullValue { get; set; }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value == null ? NullValue : NotNullValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }

    public class NullabilityToVisibilityConverter : NullabilityConverter<Visibility>
    {

    }

    public class NullabilityToBooleanConverter : NullabilityConverter<bool>
    {

    }
}
