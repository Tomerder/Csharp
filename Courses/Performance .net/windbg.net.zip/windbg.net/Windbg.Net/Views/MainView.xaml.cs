﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Diagnostics.Runtime;
using Microsoft.Win32;
using Windbg.Net.Dialogs;
using Windbg.Net.Services;
using Windbg.Net.ViewModels;

namespace Windbg.Net.Views
{
    public partial class MainView
    {
        public MainViewModel ViewModel { get; set; }
        public MainView()
        {
            InitializeComponent();
            
            this.DataContext = ViewModel = new MainViewModel();

            this.Closing += MainView_Closing;
        }

        private void MainView_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ViewModel != null) ViewModel.Dispose();
        }

    }
}
