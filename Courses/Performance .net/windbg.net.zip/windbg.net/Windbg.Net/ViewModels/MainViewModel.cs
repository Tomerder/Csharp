﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ClrMD.Extensions;
using Microsoft.Diagnostics.Runtime;
using Microsoft.Win32;
using Windbg.Net.Dialogs;
using Windbg.Net.Infra;
using Windbg.Net.Models;
using Windbg.Net.Services;

namespace Windbg.Net.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged, IDisposable
    {
        #region INotifyPropertyChanged Implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        private readonly ManagedDebuggerService _debuggerService;
        public MainViewModel()
        {
            _debuggerService = new ManagedDebuggerService();
        }

        #region Public Properties
        private ClrMDSession _clrMdSession;
        public ClrMDSession ClrMdSession
        {
            get { return _clrMdSession; }
            private set { _clrMdSession = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<ClrThread> _threads;
        public ObservableCollection<ClrThread> Threads
        {
            get { return _threads; }
            set
            {
                if (value == _threads)
                    return;

                _threads = value;

                RaisePropertyChanged();
            }
        }

        private ObservableCollection<ObjectInfo> _instances;
        public ObservableCollection<ObjectInfo> Instances
        {
            get { return _instances; }
            set { _instances = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<Stat> _stats;
        public ObservableCollection<Stat> Stats
        {
            get { return _stats; }
            set { _stats = value; RaisePropertyChanged(); }
        }

        private Stat _selectedType;
        public Stat SelectedType
        {
            get { return _selectedType; }
            set
            {
                _selectedType = value; RaisePropertyChanged();

                if (_selectedType == null)
                {
                    Instances = null;
                    return;
                }

                Instances =
                    (from obj in ClrMdSession.AllObjects
                     where obj.TypeName == _selectedType.TypeName
                     select new ObjectInfo { Address = obj.Address, Value = obj.ToDetailedString() }
                    ).ToObservableCollection();
            }
        }
        #endregion
        #region Code

        #endregion

        public ICommand AttachToProcessCommand
        {
            get
            {
                return new Command(() =>
                {
                    var selectProcessDialog = new SelectProcessDialog();

                    selectProcessDialog.ShowDialog();
                    if (selectProcessDialog.SelectedProcess == null) return;

                    var pid = selectProcessDialog.SelectedProcess.Id;

                    InitializeSession(_debuggerService.AttachToProcess(pid));
                });
            }
        }

        public ICommand LoadDumpFileCommand
        {
            get
            {
                return new Command(() =>
                {
                    var loadDumpFileDialog = new OpenFileDialog
                    {
                        Filter = "Dump Files (*.dmp)|*.dmp"
                    };

                    var dialogResult = loadDumpFileDialog.ShowDialog();
                    if (dialogResult.HasValue && dialogResult.Value)
                    {
                        var dumpFileName = loadDumpFileDialog.FileName;
                        InitializeSession(_debuggerService.LoadDumpFile(dumpFileName));
                    }
                });
            }
        }

        public ICommand FindDeadlocksCommand
        {
            get
            {
                return new Command(() =>
                {
                    var deadlocks = _debuggerService.FindDeadLocks().ToList();
                    if (deadlocks.Count > 0)
                    {
                        MessageBox.Show(string.Join(Environment.NewLine, deadlocks), "Deadlock Found!");
                    }
                    else
                    {
                        MessageBox.Show("No deadlocks found.", "We're good man.");
                    }
                });
            }
        }

        private void InitializeSession(ClrMDSession clrMdSession)
        {
            ClrMdSession = clrMdSession;

            Threads = _debuggerService.GetThreads();
            Stats = _debuggerService.GetStats();
        }

        public void Dispose()
        {
            if (ClrMdSession != null)
            {
                ClrMdSession.Dispose();
            }
        }
    }
}
