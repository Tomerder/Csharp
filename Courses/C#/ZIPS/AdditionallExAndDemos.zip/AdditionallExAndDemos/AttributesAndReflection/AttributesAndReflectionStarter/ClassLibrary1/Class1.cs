﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Class1
    {
        public void Func1()
        {
            Console.WriteLine("Hello");
        }

        public void Func2()
        {
            Console.WriteLine("f2");
        }
    }
}
