﻿using System;
namespace RectangleExercise
{
    interface IMyClass
    {
        void Eat();
        int GetAge();
        void Sleep();
    }
}
