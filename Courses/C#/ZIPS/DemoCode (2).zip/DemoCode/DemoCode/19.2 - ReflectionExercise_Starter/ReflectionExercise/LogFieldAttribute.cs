using System;

namespace ReflectionExercise
{
    //TODO 2: Add [AttribugeUsage] attribute so this attribute can be applied only to fields, and so that it cannot be applied more than once.
    public class LogFieldAttribute : Attribute
    {
    }
}
