using System;

namespace PropertiesExercise
{
    class PropertiesExerciseMain
    {
        static void Main(string[] args)
        {
            //TODO: Write a driver that accepts a filename from the command line and displays its statistics.
        }
    }
}
