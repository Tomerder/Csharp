﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalculatorImplementaion
{
    public class CalculatorNet
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public int Subtract(int a, int b)
        {
            return a - b;
        }

        public int Multiply(int a, int b)
        {
            return a * b;
        }

        public int Divide(int a, int b)
        {
            return a / b;
        }
    }
}
