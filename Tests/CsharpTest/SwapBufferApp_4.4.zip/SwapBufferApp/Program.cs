﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapBufferApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Swap buffer - youtube - client1 send file to server - server sends the file to client2 while receiving  
        }
    }
}
